// Copyright 2022 Álvaro Cortés (@ACortesDev)
// SPDX-License-Identifier: GPL-2.0-or-later
#pragma once

enum custom_layers {
    _COLEMAK,
    _LOWER,
    _RAISE,
    _ADJUST,
};
