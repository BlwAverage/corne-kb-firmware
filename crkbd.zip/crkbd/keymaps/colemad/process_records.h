// Copyright 2022 Álvaro Cortés (@ACortesDev)
// SPDX-License-Identifier: GPL-2.0-or-later
#pragma once

bool process_record_user(uint16_t keycode, keyrecord_t *record);
