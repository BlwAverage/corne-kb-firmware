# Ardakilic's Corne Layout

This layout is optimised to use Turkish characters on Corne on macOS.

Also, some size optimisations enabled in `rules.mk` and `config.h`.

Bongo cat animation implemented from: https://github.com/nwii/oledbongocat
