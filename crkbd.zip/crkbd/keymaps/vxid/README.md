# Vxid crkbd layout

Inspired by sdothum's wide planck layout.
