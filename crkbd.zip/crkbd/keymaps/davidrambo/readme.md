This is my Corne keymap, which uses Colemak and shortcuts for Linux and Windows.
