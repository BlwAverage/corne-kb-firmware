# Notes:
  * to flush firmware to keyboard use:
    ```
    $ make crkbd/rev1:antosha417:avrdude-split-right
    $ make crkbd/rev1:antosha417:avrdude-split-left
    ```

# Todo:
  [ ] do something with displayig symbols on oled screen
  [ ] count wpm
  [ ] load images
  [X] figure out how to delete word on linux
  [X] fix oled layer names
