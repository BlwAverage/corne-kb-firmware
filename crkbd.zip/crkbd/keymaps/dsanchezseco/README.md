# Dvorak keymap for CRKBD

To flash the halves use:

```
#left side
make crkbd:dsanchezseco:dfu-split-left
#right side, with RGB matrix fix
make crkbd:dsanchezseco:dfu-split-right RGB_MATRIX_SPLIT_RIGHT=yes
```
