Keyboard: Corne Keyboard (CRKBD)  
Keys: A split keyboard with 3x6 vertically staggered keys and 3 thumb keys.  
Layout: Swedish characters on main layer using tapdance. Built for eurkey keyboard layout.  
Flash instructions: Flash using avrdude, will req the hvp user space to compile.

> make crkbd:hvp:avrdude

Links:  
Github - https://github.com/qmk/qmk_firmware/tree/master/keyboards/crkbd  
Eurkey layout - https://eurkey.steffen.bruentjen.eu/
