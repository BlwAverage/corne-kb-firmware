// [CRKBD layers Init] -------------------------------------------------------//
typedef enum {
    _QWERTY,
    _NUM,
    _SYM,
    _GAME,
    _WEAPON
}CRKBD_LAYERS;

extern enum CRKBD_LAYERS crkbd_layers;
