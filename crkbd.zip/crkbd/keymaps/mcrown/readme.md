![the-frey-layout](https://raw.githubusercontent.com/MarioCorona/mcrown_pics/main/mcrown_layout.png)

# Keyboard layout by MCrown

This is all four layers:

- The top indicates the RAISE layer
- The middle indicates the DEFAULT layer
- The bottom indicates the LOWER layer
- Green indicated ADJUST layer

All the keys respond as you'd expect to the 'shift' key - i.e. on a UK/GB keyboard, `/` becomes `?` and so on.

