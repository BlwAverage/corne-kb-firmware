# bLipson
a keymap for the CRKBD/Corne geared towards professional software development on MacOS.

#### Meant for use with the following tools:

- [Intellij IDEA](https://www.jetbrains.com/idea/)
- [Rectangle](https://rectangleapp.com/)

## Building
`make crkbd:blipson`
